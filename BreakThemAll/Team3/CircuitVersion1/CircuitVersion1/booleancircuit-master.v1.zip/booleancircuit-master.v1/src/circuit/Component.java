package circuit;

public interface Component {
    boolean getValue();
}
