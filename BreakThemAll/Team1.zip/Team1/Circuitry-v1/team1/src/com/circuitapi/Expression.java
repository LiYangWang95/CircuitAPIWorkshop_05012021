package com.circuitapi;

public abstract class Expression extends Formula {
    protected Formula lhs;
}
