package com.circuitapi;

public abstract class Formula {
    abstract boolean getValue();
    abstract void setValue(boolean value);
}
