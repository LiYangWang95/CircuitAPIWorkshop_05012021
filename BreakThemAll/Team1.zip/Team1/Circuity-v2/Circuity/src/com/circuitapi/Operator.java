package com.circuitapi;

public enum Operator {
    AND,
    OR,
    NOT,
    OPERAND,
    GTE;
}
