package com.circuitapi;

public class CircuitInputException extends Exception{
    public CircuitInputException(String message){
        super(message);

    }

}
