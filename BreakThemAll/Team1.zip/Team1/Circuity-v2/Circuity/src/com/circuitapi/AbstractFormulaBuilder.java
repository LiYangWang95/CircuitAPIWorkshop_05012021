package com.circuitapi;

abstract class AbstractFormulaBuilder {
    public abstract Formula getFormula(Operator operator);
}
