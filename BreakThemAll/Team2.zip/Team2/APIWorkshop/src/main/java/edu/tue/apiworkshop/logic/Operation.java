package edu.tue.apiworkshop.logic;

public abstract class Operation extends LogicFormula{
    
}