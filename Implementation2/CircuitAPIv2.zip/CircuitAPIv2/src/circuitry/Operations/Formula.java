/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circuitry.Operations;

import java.text.Normalizer;

/**
 *
 * @author 20204909
 */
public abstract class Formula {
    public abstract boolean getValue();
    public abstract double getDValue();

    
}
